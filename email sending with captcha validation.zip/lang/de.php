<?php

//Detch

//index 
    $lang['main_text'] = 'Ticket Portal';
    $lang['main_txt'] = 'NEUES TICKET ERSTELLEN';
    $lang['footer_3'] = "Ticket Statusabfrage";
    $lang['popup_header'] = "Neues Ticket erstellen";
    $lang['email_add'] = "Email-Adresse";
    $lang['row_2'] = "Priorität";
    $lang['pop_title'] = "Betreff";
    $lang['pop_text'] = "Beschreibung";
    $lang['file_upload'] = "Datei hochladen";
    $lang['send'] = "Erstellen";
    $lang['close'] = "Abbrechen";

?>