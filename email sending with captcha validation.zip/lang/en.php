<?php

//English

//index 
    $lang['main_text'] = 'Ticket portal';
    $lang['main_txt'] = "CREATE A NEW TICKET";
    $lang['footer_3'] = "Ticket status query";
    $lang['popup_header'] = "Create A NEW TICKET";
    $lang['email_add'] = "E-mail address";
    $lang['row_2'] = "Priority";
    $lang['pop_title'] = "Regarding";
    $lang['pop_text'] = "Description";
    $lang['file_upload'] = "Upload file";
    $lang['send'] = "Create";
    $lang['close'] = "Abort";

?>